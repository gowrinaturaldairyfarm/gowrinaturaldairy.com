# Gowri Natural Dairy Farm Website

## Deploy
1. Upload this folder to GitHub.
2. Connect the GitHub repository to Netlify.
3. Connect the GoDaddy domain to Netlify using the DNS records shown by Netlify.

## Important
- Product prices are currently: A2 ₹80/L, Cow ₹60/L, Buffalo ₹100/L.
- Donation and enquiry forms are demo forms. Connect them to a secure backend/email/CRM and a verified payment gateway before accepting money.
- Do not publish bank/UPI/payment details until they are verified.
- Any equity/investment offer should be legally and financially reviewed before publication.
